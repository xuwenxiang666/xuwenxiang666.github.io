package com.example.showlowversion;

import com.example.version.ShowVersion;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowLowVersionApplication {

    public static void main(String[] args) {

        SpringApplication.run(ShowLowVersionApplication.class, args);
        ShowInfo.Print();
    }

}
