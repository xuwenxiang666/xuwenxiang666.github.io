package com.example.showlowversion;

import com.example.version.ShowVersion;

/**
 * @author 徐文祥
 * @since 2024/06/23 23:10
 */
public class ShowInfo {
    public static void Print(){
        System.out.println("---展示版本1的ShowVersion---");
        ShowVersion.printVersion();
        System.out.println("---展示版本1的ShowVersion---");
    }
}
