package com.example.showlowversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowLowVersionApplicationTests {

    @Test
    void contextLoads() {
    }

}
