package com.example.version;


public class ShowVersion {
    public static void  printVersion(){
        System.out.println("this is version2");
    }
}
