package com.example.version;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VersionApplicationTests {

    @Test
    void contextLoads() {
    }

}
