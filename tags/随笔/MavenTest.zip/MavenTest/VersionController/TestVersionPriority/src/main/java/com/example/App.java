package com.example;

import com.example.showlowversion.ShowInfo;
import com.example.version.ShowVersion;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("验证最短路径优先：");
        ShowVersion.printVersion();

        System.out.println();
        System.out.println();
        System.out.println("验证间接引用下的包");
        ShowInfo.Print();


    }
}
